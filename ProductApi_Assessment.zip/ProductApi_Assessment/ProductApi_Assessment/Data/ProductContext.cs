﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using ProductApi_Assessment.Model;

namespace ProductApi_Assessment.Data
{
    public class ProductContext: IdentityDbContext<ApplicationUser>
    {
        public ProductContext(DbContextOptions<ProductContext> options): base(options)
        {

        }
        public DbSet<Product> Products { get; set; }

        public override int SaveChanges() { 
            var entities = ChangeTracker.Entries<Product>().Where(e => e.State == EntityState.Added);
            foreach (var entity in entities) 
            {
                entity.Entity.id = GenerateUniqueSixDigitId(); 
            } 
            return base.SaveChanges();
        }
        private int GenerateUniqueSixDigitId()
        {
            var random = new Random(); int newId; do
            {
                newId = random.Next(100000, 999999); 
            } 
            while (Products.Any(e => e.id == newId));
            return newId; 
        }
    }
}
