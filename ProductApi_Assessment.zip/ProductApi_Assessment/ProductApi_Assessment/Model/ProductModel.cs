﻿namespace ProductApi_Assessment.Model
{
    public class ProductModel
    {
        public int id { get; set; }
        public string? productName { get; set; }
        public int stockAvailable { get; set; }
    }
}
