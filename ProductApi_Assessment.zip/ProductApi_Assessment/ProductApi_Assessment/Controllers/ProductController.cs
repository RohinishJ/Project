using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProductApi_Assessment.Model;
using ProductApi_Assessment.Repository;

namespace ProductApi_Assessment.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class ProductController : ControllerBase
    {
        
        private readonly IProductRepo _productRepo;

        public ProductController(IProductRepo productRepo)
        {
            _productRepo = productRepo;
        }

        [HttpGet("")]
        public async Task<IActionResult> GetAllProducts()
        {
            var products = await _productRepo.GetAllProducts();
            return Ok(products);
        }

        [HttpGet("{productId}")]
        public async Task<IActionResult> GetProductById([FromRoute]int productId)
        {
            var product = await _productRepo.GetProductById(productId);

            if(product == null)
            {
                return NotFound();
            }

            return Ok(product);
        }

        [HttpPost("")]
        public async Task<IActionResult> AddProduct([FromBody]ProductModel productModel)
        {
            var productId = await _productRepo.AddProduct(productModel);

            return CreatedAtAction(nameof(GetProductById), new { productId = productId, controller = "Product" }, productId);
        }

        [HttpPut("decrement-stock/{id}/{quantity}")]
        public async Task<IActionResult> DecrementStock([FromRoute] int id, int quantity)
        {
            await _productRepo.DecrementStock(id, quantity);

            return Ok();
        }
        [HttpPut("add-to-stock/{id}/{quantity}")]
        public async Task<IActionResult> AddToStock([FromRoute] int id, int quantity)
        {
            await _productRepo.AddToStock(id, quantity);

            return Ok();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProduct([FromRoute] int id)
        {
            await _productRepo.DeleteProduct(id);

            return Ok();
        }
    }
}