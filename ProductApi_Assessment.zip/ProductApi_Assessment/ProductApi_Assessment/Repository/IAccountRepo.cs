﻿using Microsoft.AspNetCore.Identity;
using ProductApi_Assessment.Model;

namespace ProductApi_Assessment.Repository
{
    public interface IAccountRepo
    {
        Task<IdentityResult> SignUp(SignUpModel signUpModel);
        Task<string> Login(SignInModel signInModel);
    }
}
