﻿using ProductApi_Assessment.Model;

namespace ProductApi_Assessment.Repository
{
    public interface IProductRepo
    {
        Task<List<ProductModel>> GetAllProducts();
        Task<ProductModel> GetProductById(int productId);
        Task<int> AddProduct(ProductModel product);
        Task DecrementStock(int id, int decrementValue);
        Task AddToStock(int id, int incrementValue);
        Task DeleteProduct(int productId);
    }
}
