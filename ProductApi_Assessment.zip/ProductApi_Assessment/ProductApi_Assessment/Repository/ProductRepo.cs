﻿using Microsoft.EntityFrameworkCore;
using ProductApi_Assessment.Data;
using ProductApi_Assessment.Model;

namespace ProductApi_Assessment.Repository
{
    public class ProductRepo : IProductRepo
    {
        private readonly ProductContext _context;
        public ProductRepo(ProductContext context)
        {
            _context = context;
        }

        public async Task<List<ProductModel>> GetAllProducts()
        {
            var records = await _context.Products.Select(x => new ProductModel() {
                id = x.id,
                productName = x.productName,
                stockAvailable = x.stockAvailable
            }).ToListAsync();

            return records;
        }

        public async Task<ProductModel> GetProductById(int productId)
        {
            var records = await _context.Products.Where(y => y.id == productId).Select(x => new ProductModel()
            {
                id = x.id,
                productName = x.productName,
                stockAvailable = x.stockAvailable
            }).FirstOrDefaultAsync();

            return records;
        }
        public async Task<int> AddProduct(ProductModel product)
        {
            var objProduct = new Product()
            {
                stockAvailable = product.stockAvailable,
                productName = product.productName
            };
            await _context.Products.AddAsync(objProduct);
            _context.SaveChanges();

            return objProduct.id;
        }
        public async Task DecrementStock(int id, int decrementValue)
        {
            var product = await _context.Products.FindAsync(id);
            if(product != null)
            {
                product.stockAvailable = product.stockAvailable - decrementValue;
                _context.SaveChanges();
            }
        }
        public async Task AddToStock(int id, int incrementValue)
        {
            var product = await _context.Products.FindAsync(id);
            if (product != null)
            {
                product.stockAvailable = product.stockAvailable + incrementValue;
                _context.SaveChanges();
            }
        }

        public async Task DeleteProduct(int productId)
        {
            var product = new Product() { id = productId };

            _context.Products.Remove(product);
            await _context.SaveChangesAsync();
        }
    }
}
